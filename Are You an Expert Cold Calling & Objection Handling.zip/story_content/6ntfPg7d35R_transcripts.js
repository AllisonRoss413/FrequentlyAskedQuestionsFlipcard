
(function() {
    const data = {"transcripts":[{"name":"captions","cues":[]}]};
    window.globalLoadJsAsset('story_content/6ntfPg7d35R_transcripts.js', JSON.stringify(data));
})();